﻿namespace DeleteFilesAfterXDays
{
    public partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.simulateButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.pathBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.outputBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.countBox = new System.Windows.Forms.TextBox();
            this.helpButton = new System.Windows.Forms.Button();
            this.maskBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.daysBox = new System.Windows.Forms.NumericUpDown();
            this.backgroundStartUpDelay = new System.ComponentModel.BackgroundWorker();
            this.backgroundDelete = new System.ComponentModel.BackgroundWorker();
            this.backgroundGetFiles = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.daysBox)).BeginInit();
            this.SuspendLayout();
            // 
            // simulateButton
            // 
            this.simulateButton.Location = new System.Drawing.Point(0, 67);
            this.simulateButton.Name = "simulateButton";
            this.simulateButton.Size = new System.Drawing.Size(201, 23);
            this.simulateButton.TabIndex = 0;
            this.simulateButton.Text = "Simulate (no delete)";
            this.simulateButton.UseVisualStyleBackColor = true;
            this.simulateButton.Click += new System.EventHandler(this.simulateButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(207, 67);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(201, 23);
            this.deleteButton.TabIndex = 1;
            this.deleteButton.Text = "Delete files";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // pathBox
            // 
            this.pathBox.Location = new System.Drawing.Point(0, 23);
            this.pathBox.Name = "pathBox";
            this.pathBox.Size = new System.Drawing.Size(201, 20);
            this.pathBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Path (like \\\\server\\webcam)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(327, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Number of days";
            // 
            // outputBox
            // 
            this.outputBox.Enabled = false;
            this.outputBox.Location = new System.Drawing.Point(0, 131);
            this.outputBox.Name = "outputBox";
            this.outputBox.Size = new System.Drawing.Size(316, 20);
            this.outputBox.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Output";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(322, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Count";
            // 
            // countBox
            // 
            this.countBox.Enabled = false;
            this.countBox.Location = new System.Drawing.Point(322, 131);
            this.countBox.Name = "countBox";
            this.countBox.Size = new System.Drawing.Size(122, 20);
            this.countBox.TabIndex = 8;
            // 
            // helpButton
            // 
            this.helpButton.Location = new System.Drawing.Point(415, 67);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(29, 23);
            this.helpButton.TabIndex = 10;
            this.helpButton.Text = "?";
            this.helpButton.UseVisualStyleBackColor = true;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // maskBox
            // 
            this.maskBox.Location = new System.Drawing.Point(207, 23);
            this.maskBox.Name = "maskBox";
            this.maskBox.Size = new System.Drawing.Size(109, 20);
            this.maskBox.TabIndex = 2;
            this.maskBox.Text = "*.*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(207, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Mask (like *.jpg)";
            // 
            // daysBox
            // 
            this.daysBox.Location = new System.Drawing.Point(325, 23);
            this.daysBox.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
            this.daysBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.daysBox.Name = "daysBox";
            this.daysBox.Size = new System.Drawing.Size(119, 20);
            this.daysBox.TabIndex = 3;
            this.daysBox.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // backgroundStartUpDelay
            // 
            this.backgroundStartUpDelay.WorkerReportsProgress = true;
            this.backgroundStartUpDelay.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundStartUpDelay_DoWork);
            this.backgroundStartUpDelay.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundStartUpDelay_ProgressChanged);
            this.backgroundStartUpDelay.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundStartUpDelay_RunWorkerCompleted);
            // 
            // backgroundDelete
            // 
            this.backgroundDelete.WorkerReportsProgress = true;
            this.backgroundDelete.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundDelete_DoWork);
            this.backgroundDelete.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundDelete_ProgressChanged);
            this.backgroundDelete.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundDelete_RunWorkerCompleted);
            // 
            // backgroundGetFiles
            // 
            this.backgroundGetFiles.WorkerReportsProgress = true;
            this.backgroundGetFiles.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundGetFiles_DoWork);
            this.backgroundGetFiles.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundGetFiles_RunWorkerCompleted);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 162);
            this.Controls.Add(this.daysBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.maskBox);
            this.Controls.Add(this.helpButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.countBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pathBox);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.simulateButton);
            this.Name = "MainForm";
            this.Text = "DeleteFilesAfterXDays";
            this.Deactivate += new System.EventHandler(this.MainForm_Deactivate);
            ((System.ComponentModel.ISupportInitialize)(this.daysBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button simulateButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.TextBox pathBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox outputBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox countBox;
        private System.Windows.Forms.Button helpButton;
        private System.Windows.Forms.TextBox maskBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown daysBox;
        private System.ComponentModel.BackgroundWorker backgroundStartUpDelay;
        private System.ComponentModel.BackgroundWorker backgroundDelete;
        private System.ComponentModel.BackgroundWorker backgroundGetFiles;
    }
}

