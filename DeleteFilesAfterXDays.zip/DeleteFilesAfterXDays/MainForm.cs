﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeleteFilesAfterXDays
{
    public partial class MainForm : Form
    {
        /*  
         * steps for auto-run:
         * 1- load from inifile, launch background startupdelay
         * 2- upon complete, if auto, then launch background delete files
         * 3- upon complete, if auto, then exit program
         * 
         * steps for manual run
         * 1- load from inifile, show form, wait for click
         * 2- on click, launch ackground delete files (or simulate)
         * 3- on complete, if not auto, do nothing
         * */

        private bool _exitWhenComplete;
        public MainForm(int nrOfParams)
        {
            InitializeComponent();
            _filesToDelete = new List<FileInfo>();
            _filesDeleted = 0;
            _exitWhenComplete = nrOfParams > 0;
            bool settingsLoaded = LoadFromIniFile();

            // check for automatic functioning
            if (_exitWhenComplete && settingsLoaded)
            {
                this.Show();

                BlockUI();

                backgroundStartUpDelay.RunWorkerAsync();
            }
        }
  
        private void simulateButton_Click(object sender, EventArgs e)
        {
            ProcessButtonClick(true);
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            ProcessButtonClick(false);
        }

        private List<FileInfo> _filesToDelete;
        private int _filesDeleted;

        private void ProcessButtonClick(bool simulate)
        {
            // init
            ShowPleaseWait();

            // get userdata
            string path = pathBox.Text;
            string mask = maskBox.Text;
            int days = (int)daysBox.Value;

            if (Directory.Exists(path))
            {
                // set inputs disabled.
                BlockUI();
                // get list of files to be deleted.
                GetFiles(path, mask, days, simulate);

                
            }
            else
            {
                displayAlert("No directory found. Check path!");
            }
        }



        private void helpButton_Click(object sender, EventArgs e)
        {
            helpForm help = new helpForm();
            help.Show();
        }

        public static void displayAlert(string message)
        {
            string caption = "Attention!";
            MessageBoxButtons buttons = MessageBoxButtons.OK;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
        }

        private void GetFiles(string path, string mask, int nrOfDays, bool simul)
        {
           backgroundGetFiles.RunWorkerAsync(new string[4] { path, mask, nrOfDays.ToString(), simul.ToString()});
        }
        
        private void ShowPleaseWait()
        {
            countBox.Text = "...";
            outputBox.Text = "  working - please wait ";
            this.Refresh(); // repaint
        }
        private void ShowStartDelay(int n)
        {
            countBox.Text = n.ToString();
            outputBox.Text = "Delay for network and HD to start.";
            this.Refresh(); // repaint
        }

        private void SetDefaultValues()
        {
            countBox.Text = "-";
            outputBox.Text = "- ";
            pathBox.Text = @"\\server\webcam";
            maskBox.Text = "*.jpg";
            this.Refresh(); // repaint
        }

        private bool LoadFromIniFile()
        {
            bool result = false;
            string iniFile = Directory.GetCurrentDirectory() + @"\DeleteFilesAfterXDays.ini";
            if (File.Exists(iniFile))
            {
                try
                {   // Open the text file using a stream reader.
                    using (StreamReader sr = new StreamReader(iniFile))
                    {
                        // read from stream into objects.
                        pathBox.Text = sr.ReadLine();
                        maskBox.Text = sr.ReadLine();
                        int days = 0;
                        if (int.TryParse(sr.ReadLine(), out days))
                        {
                            daysBox.Value = days;
                        }
                    }
                    result = true;
                }
                catch 
                {
                    displayAlert("The ini-file could not be read.");
                }
            }
            return result;
        }

        private void WriteToIniFile()
        {
            string iniFile = Directory.GetCurrentDirectory() + @"\DeleteFilesAfterXDays.ini";
            try
            {
                System.IO.StreamWriter file = new System.IO.StreamWriter(iniFile);
                file.WriteLine(pathBox.Text);
                file.WriteLine(maskBox.Text);
                file.WriteLine(daysBox.Value.ToString());
                file.Close();
            }
            catch (Exception e)
            {
                displayAlert("The ini-file could not be written.");
            }
        }

        private void MainForm_Deactivate(object sender, EventArgs e)
        {
            WriteToIniFile();
        }

        private void BlockUI()
        {
            pathBox.Enabled = false;
            maskBox.Enabled = false;
            daysBox.Enabled = false;
            simulateButton.Enabled = false;
            deleteButton.Enabled = false;
        }

        private void FreeUI()
        {
            pathBox.Enabled = true;
            maskBox.Enabled = true;
            daysBox.Enabled = true;
            simulateButton.Enabled = true;
            deleteButton.Enabled = true;
        }

        #region background delaystartup

        private void backgroundStartUpDelay_DoWork(object sender, DoWorkEventArgs e)
        {            
            // startup delay for HDs and network to come up.
            for (var i = 20; i >= 0; i--)
            {
                // run SLEEP in this seperate thread to keep appl responsive
                Thread.Sleep(1000);
                backgroundStartUpDelay.ReportProgress(i);                
            }
        }
        private void backgroundStartUpDelay_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            ShowStartDelay(e.ProgressPercentage);
        }

        private void backgroundStartUpDelay_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // if there was startupdelay, then this is automatic-fuctioning. So call delete.
            ProcessButtonClick(false);
        }
        #endregion
        #region background Delete Files

        private void backgroundDelete_DoWork(object sender, DoWorkEventArgs e)
        {
            if (_filesToDelete.Count % 10 ==0)
            {
                backgroundDelete.ReportProgress(1);
            }
            if (_filesToDelete.Count>0)
            {
                FileInfo file = _filesToDelete.First();
                _filesToDelete.Remove(file);
                file.Delete();
                _filesDeleted++;
            }

        }



        private void backgroundDelete_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            countBox.Text = _filesToDelete.Count.ToString();
            outputBox.Text = _filesToDelete.Any() ? _filesToDelete.FirstOrDefault().Name : ".";
        }

        private void backgroundDelete_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (_filesToDelete.Count > 0)
            {
                backgroundDelete.RunWorkerAsync();
            }
            else
            {
                outputBox.Text = "Deletion done.";
                countBox.Text = _filesDeleted.ToString();

                if (_exitWhenComplete)
                {
                    // wait few seconds so info can be read.
                    Thread.Sleep(4000);

                    //exit
                    System.Windows.Forms.Application.Exit();
                }

                FreeUI();
            }
        }
        #endregion
        #region background getFiles

        private void backgroundGetFiles_DoWork(object sender, DoWorkEventArgs e)
        {
            string[] arguments = (string[])e.Argument;
            string path = arguments[0];
            string mask = arguments[1];
            int nrOfDays = 0;
            int.TryParse(arguments[2], out nrOfDays);            

            DateTime selectionTime = DateTime.Now.AddDays(-1 * nrOfDays);

            DirectoryInfo info = new DirectoryInfo(path);
            _filesToDelete = info.GetFiles(mask).Where(f => f.CreationTime < selectionTime).ToList();
            _filesDeleted = 0;

        }

       

        private void backgroundGetFiles_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!_exitWhenComplete)
            {
                outputBox.Text = "Files found:";
                countBox.Text = _filesToDelete.Count.ToString();
                FreeUI();
            }
            else // so when deleting automaticly.
            {
                // start deleting in separate thread
                backgroundDelete.RunWorkerAsync();
            }
        }
        #endregion


    }
}
